// export const createProject = (project) =>{
//    return(dispatch,getState,{getFirestore,getFirebase})=>{
//     //make async call to database add input data to our firebase database
//     const firestore = getFirestore();
//     firestore.collection('projects').add({
//         ...project,
//         authorFirstName:'nyi',
//         authorLastName:'zaw',
//         authorId:12345,
//         createdAt:new Date()
//     }).then(()=>{
//         dispatch({
//             type:'CREATE_PROJECT',
//             project
//         })
//     }).catch((err) =>{
//         dispatch({type:'CREATE_PROJECT_ERROR',err})
//     })
   
//    }
// }
import firestore from '../../config/fbConfig';

//retreve project data from firebase projects collection
export const retrieveProject = () => dispatch =>{
    const projects = []
    const projectData = firestore.collection('projects').get();
    projectData.then( (snapshot) => {
    snapshot.docs.forEach( item => {
        const project = item.data();
        project.id = item.id;
        projects.push(project);
        
     });
     console.log('ph',projects);
     dispatch({
      type: 'FETCH_PORJECTS',
      data : projects
    });
     
    })
};

//console.log('re',retrieveProject);

//add new project to firebase when we create new project
export const createProject = (project) => dispatch =>{
    firestore.collection('projects').add({
        ...project,
        authorFirstName:'nyi',
        authorLastName:'zaw',
        authorId:12345,
        createdAt:new Date()
    })
    .then( () =>{
        dispatch({
            type:'CREATE_PROJECT',
            project:project
        })
    }).catch((err)=>{
        dispatch({type:'CREATE_PROJECT_ERROR',err})
    });
    
}
