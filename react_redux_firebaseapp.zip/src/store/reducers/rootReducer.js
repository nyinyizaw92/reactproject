import { combineReducers} from 'redux'
import authReducer from './authReducer'
import projectReducer from './projectReducer'
//import { firestoreReducer } from 'redux-firestore'


const rootReducer = combineReducers({
    auth:authReducer, //update auth information
    project:projectReducer, //update project information 
   // firestore:firestoreReducer
})

export default rootReducer