// const initState = {
  
// }

const projectReducer = (state =[],action) =>{
    switch(action.type){
        case 'CREATE_PROJECT':
        return[
            ...state,
            action.project
        ]
        //console.log('created project',action.project);
       // return  state;

        case 'CREATE_PROJECT_ERROR':
        console.log('created project error',action.err);
        return state;

        case 'FETCH_PORJECTS':
        console.log('ap',action.projectData)
        return [...action.data]


        default:
        return state
    }
    
}


export default projectReducer 