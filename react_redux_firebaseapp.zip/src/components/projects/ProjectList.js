import React from 'react'
import ProjectSummary from './ProjectSummary'

class ProjectList extends React.Component {
   
    render(){
        console.log('projectList',this.props.project)
        return (
            <div className="project-list secction">
            <h1>{this.props.project.title}</h1>
                 {/* <ProjectSummary  project={this.props.project} /> */}
     
             </div>
        )
            
        }
}


export default ProjectList