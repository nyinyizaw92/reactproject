import React,{Component} from 'react'
import Notification from './Notification'
import ProjectList from '../projects/ProjectList'
import {projectReducer} from '../../store/reducers/projectReducer'
import { connect } from 'react-redux'
import {retrieveProject} from '../../store/actions/projectAction'
//import { compose } from 'redux'
//import { firestoreConnect } from 'react-redux-firebase'
//import { reactReactFirebase } from 'react-redux-firebase'



class Dashboard extends React.Component{
    constructor(props){
        super(props);
     this.props.retrieveProject() ;
       
    }
    render(){
       
        const projects = this.props.projectReducer;
    //console.log('articlesdata',articles);
    //const users = this.props.users;
    //console.log('userdata',users);
    if(projects == undefined){
        console.log('pro',projects);
        return(
            <h1>hi</h1>
        )
        
    //   console.log(articles);
    //   return articles.map((article, index) => {  
           
    //     const author = users.find(obj => obj.id == article.created_by);
    //     console.log('articlellist',author);
    //     return <Article key={index} article={article} author={article.author} />;
    //   });
    }

    return null;
    }
}

const mapStateToProps = state =>({
   projectReducer:state.projectReducer,
  
   
});

const mapDispatchToProps = {
    retrieveProject
  }

  
//export default Dashboard
export default connect(mapStateToProps,mapDispatchToProps)(Dashboard)
// export default compose(
//     connect(mapStateToProps),
//     firestoreConnect([
//         {collection:'projects'}
//     ])
// )(Dashboard)


{/* <div className="dashboard container">
<div className="row">

    <div className="col s12 m6">
  
    {projects && projects.map(project =>{
         return (
             <ProjectList  project={project} key={project.id}/>
        )
     })}
    </div>
    <div className="col s12 m5 offset-m1">
        <Notification />
    </div>
</div>
</div> */}