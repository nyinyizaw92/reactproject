import React, { Component } from 'react'

class Notification extends Component {
  render() {
    return (
      <div>
        <h3>Notification</h3>
      </div>
    )
  }
}

export default Notification
